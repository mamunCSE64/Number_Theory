#include <bits/stdc++.h>
#include <iostream>
#define ll long long int
#define pb push_back
#define pob pop_back
#define pf push_front
#define pof pop_front
#define gcd __gcd
#define int_string to_string
#define string_int stoi
#define mn(v) *min_element(v.begin(), v.end())
#define mx(v) *max_element(v.begin(), v.end())
#define index_character s.find('character')
#define countxchar count(s.begin(), s.end(), 'x')
#define index_ofX_vector find(v.begin(), v.end(), x) - v.begin()
#define yes cout << "YES" << endl
#define no cout << "NO" << endl
#define n1 cout << "-1" << endl
#define sorted is_sorted(v.begin(), v.end())
#define nl << endl
#define sp << " "
#define mp make_pair
#define fi first
#define se second
#define Mx INT_MAX
#define Mn INT_MIN
#define mod %1000000007
const ll N = 1e6+5;
//   freopen("input.txt","r",stdin);freopen("output.txt","w",stdout);
// BesidesDuplicateCharacterEraseInString s.erase(unique(s.begin(), s.end()), s.end());
// Upper/lower-> transform(s.begin(), s.end(), s.begin(), ::toupper/tolower)
using namespace std;
ll i, j, k, n, m;
ll a[26];
//  Don't get stuck on a single approach for long, think of multiple ways
//  **********************|| Main Code ||********************************
bool comp(pair<int, int> x, pair<int, int> y) {
    if (x.first < y.first) return true;
    if (x.first > y.first) return false;
    if (x.second >= y.second) return true;
    return false;
}

int main()
{    
    ll test = 1;
    // cin >> test;   
    while (test--)
    {    
       ll n,x,y;
       cin>>n;
       vector<pair<ll,ll>> v;
       while(n--){
            cin>>x>>y;
            v.pb({x,y});
       }
       sort(v.begin(),v.end(), comp);
       for(auto x: v) cout << x.fi sp << x.se nl;
    }
}
