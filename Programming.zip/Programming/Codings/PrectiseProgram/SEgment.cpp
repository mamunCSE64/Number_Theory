#include <bits/stdc++.h>
#include <iostream>
#define ll long long int
#define pb push_back
#define pob pop_back
#define pf push_front
#define pof pop_front
#define gcd __gcd
#define int_string to_string
#define string_int stoi
#define mn(v) *min_element(v.begin(), v.end())
#define mx(v) *max_element(v.begin(), v.end())
#define index_character s.find('character')
#define countxchar count(s.begin(), s.end(), 'x')
#define index_ofX_vector find(v.begin(), v.end(), x) - v.begin()
#define yes cout << "YES" << endl
#define no cout << "NO" << endl
#define n1 cout << "-1" << endl
#define sorted is_sorted(v.begin(), v.end())
#define nl << endl
#define sp << " "
#define mp make_pair
#define fi first
#define se second
#define Mx LLONG_MAX
#define Mn LLONG_MIN
#define mod %1000000007
// freopen("input.txt","r",stdin);freopen("output.txt","w",stdout);
// BesidesDuplicateCharacterEraseInString s.erase(unique(s.begin(), s.end()), s.end());
// Upper/lower-> transform(s.begin(), s.end(), s.begin(), ::toupper/tolower);
using namespace std;
ll i, j, k, n, m;
const ll e=1e+9;
bool comp(pair<ll,ll> a,pair<ll,ll> b){ if(a.fi==b.fi) return (a.se>b.se);
return (a.fi<b.fi); }
// Don't get stuck on a single approach for long, think of multiple ways
// **********************|| Main Code ||********************************
// 

const ll N=2e5+5;
ll tree[4*N];
ll ar[N];

void build(ll at, ll b, ll e)
{
	if (b==e){tree[at]=ar[b];return;}	
	ll mid=(b+e)/2;
	build(2*at,b,mid),build(2*at+1,mid+1,e);
	tree[at]=(tree[2*at]+tree[2*at+1]);
}
void update(ll at,ll b,ll e,ll idx,ll val)
{
	if(b==e){tree[at]=val;return;}	
	ll mid=(b+e)/2;
	if(idx<=mid) update(2*at,b,mid,idx,val);
	else update(2*at+1,mid+1,e,idx,val);
	tree[at]=(tree[2*at]+tree[2*at+1]);
}
ll query(ll at,ll b,ll e,ll l,ll r)
{
	ll x,y,mid;
	if(r<b or e<l) return 0;
	if(l<=b and e<=r) return tree[at];
	mid=(b+e)/2;
	x=query(2*at,b,mid,l,r);
	y=query(2*at+1,mid+1,e,l,r);
	return x+y;
}

int main()
{
	ll test=1;
	//cin>>test;
	while(test--)
	{
		ll n,q,l,r,idx,val,op;
		cin >>n>>q;	
		for(i=1;i<=n;i++) cin >> ar[i];
		build(1,1,n);	
		cout << "Before update" nl;
		for(i=1;i<=9;i++) cout << tree[i] sp;cout nl;
		while(q--)
		{			
			cin>>op;
			if(op==1)cin>>idx>>val,update(1,1,n,idx,val);			
			else cin>>l>>r, cout << query(1,1,n,l,r) nl;			
		}
		cout << "After update" nl;
		for(i=1;i<=9;i++) cout << tree[i] sp;cout nl;		
	}
}