#include <bits/stdc++.h>
#include <iostream>
#define ll long long int
#define pb push_back
#define pob pop_back
#define pf push_front
#define pof pop_front
#define gcd __gcd
#define int_string to_string
#define string_int stoi
#define mn(v) *min_element(v.begin(), v.end())
#define mx(v) *max_element(v.begin(), v.end())
#define index_character s.find('character')
#define countxchar count(s.begin(), s.end(), 'x')
#define index_ofX_vector find(v.begin(), v.end(), x) - v.begin()
#define yes cout << "YES" << endl
#define no cout << "NO" << endl
#define n1 cout << "-1" << endl
#define sorted is_sorted(v.begin(), v.end())
#define nl << endl
#define sp << " "
#define mp make_pair
#define fi first
#define se second
#define Mx INT_MAX
#define Mn INT_MIN
#define mod 1000000007
// freopen("input.txt","r",stdin);freopen("output.txt","w",stdout);
// BesidesDuplicateCharacterEraseInString s.erase(unique(s.begin(), s.end()), s.end());
// Upper/lower-> transform(s.begin(), s.end(), s.begin(), ::toupper/tolower);
using namespace std;
ll i, j, k,n;
ll a[26];
// Don't get stuck on a single approach for long, think of multiple ways
// **********************|| Main Code ||********************************
void max_heapify(ll a[], ll n, ll i){
	ll largest=i;ll l=2*i;ll r=l+1;
	if (l <= n and a[l] > a[largest])
		largest = l;	 
	if (r <=n and a[r] > a[largest])
		largest = r;	
	if (largest != i){
		swap(a[i], a[largest]);		
		max_heapify(a, n, largest);
	}
}
void buildmaxHeap(ll a[],ll n){
	for(i=n/2;i>=1;i--) max_heapify(a,n,i);
	for(i=1;i<=n;i++) cout << a[i] sp;cout nl nl;
}
void heapSort(ll a[], ll n){	 
	for (i=n;i>1;i--){		 
		swap(a[1], a[i]);
		max_heapify(a, i-1, 1);
	}
} 
int main()
{ 
    ll test = 1;
    // cin >> test;
    again:
    while (test--)
    {   
		ll n;
		cin>>n;
		ll a[n+1];
		for(i=1;i<=n;i++) cin>>a[i];	    
		buildmaxHeap(a,n);
		heapSort(a, n); 
		for(i=1;i<=n;i++) cout << a[i] sp;cout nl;		
    } 
}
 