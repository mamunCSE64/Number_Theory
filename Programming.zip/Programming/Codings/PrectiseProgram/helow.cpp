#include<bits/stdc++.h>
using namespace std;
int minimumSum(int a[],int low,int high){
    if(low>high)return INT_MAX;
    if(low==high)return a[low];
    int mid=low+(high-low)/2;    
    int leftSum=INT_MAX,rightSum=INT_MAX,sum;
    sum=0;    
    for(int i=mid;i>=low;i--){
        sum+=a[i];
        leftSum=min(leftSum,sum);
    }
    sum=0;
    for(int i=mid+1;i<=high;i++){
        sum+=a[i];
        rightSum=min(rightSum,sum);
    }
    int takeTheWholeSegment=leftSum+rightSum;
    int Left = minimumSum(a,low,mid);
    int Right = minimumSum(a,mid+1,high);
    return min({takeTheWholeSegment,Left,Right});
}
int main(){
    int a[] = {-2,1,-3,4,-1,2,1,-5,4};
    int n=9;
    int ans = minimumSum(a,0,n-1);
    cout<<ans<<endl;
}