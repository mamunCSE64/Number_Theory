#include<bits/stdc++.h>
using namespace std;
long long int parent[10000];
long long int child[10000];

void Init(long long int n);
long long int froot(long long int node);
void Union(long long int u,long long int v);
double distance(double x1,long long int y1,long long int x2,long long int y2);

struct ok {
    long long int x,y;
};
struct EdgeInformation{
    long long int u,v;
    double w;
    bool operator<(const EdgeInformation& e)const{
        return (this->w<e.w);
    }
};

int main(){
    long long int n;
    cin>>n;
    Init(n);
    vector<ok> a(n+1);
    for(long long int i=1;i<=n;i++)
        cin>>a[i].x>>a[i].y;
    vector<EdgeInformation> edges;

    for(long long int i=1;i<=n;i++){
        for(long long int j=i+1;j<=n;j++){
            long long int u=i, v=j;
            double w = distance(a[i].x,a[i].y,a[j].x,a[j].y);
            edges.push_back({u,v,w});
        }
    }
    sort(edges.begin(),edges.end());
    long long int count=0;
    double cost=0;
    for(long long int i=0;count<n-1;i++){
        long long int u=edges[i].u,v=edges[i].v;
        if(froot(u)==froot(v)) continue;		
        else Union(u,v),cost+=edges[i].w,count++;
    }
    cout<<"Expenditure: "<<cost<<endl;
    return 0;
}
// f1
void Init(long long int n){
    for(long long int i=0;i<=n+1;i++)  parent[i]=i,child[i]=1;
}
// f2
double distance(double x1,long long int y1,long long int x2,long long int y2){
double r = sqrt(((x1-x2)*(x1-x2))+((y1-y2)*(y1-y2)));
return r;
}
// f3
void Union(long long int u,long long int v){
    long long int root_u = froot(u),root_v = froot(v);	 

    if(child[root_u]>=child[root_v]){
        parent[root_v]=parent[root_u];
        child[root_u]+=child[root_v];
    }
    else if(child[root_u]<child[root_v]){
        parent[root_u]=parent[root_v];
        child[root_v]+=child[root_u];
    }
}
// f4
long long int froot(long long int node){
long long int r=node; 
    while(true){
        if(parent[node]==node)	return node;		
        node=parent[node];
    }
}