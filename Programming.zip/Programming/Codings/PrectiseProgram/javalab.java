import java.util.Scanner;
public class javalab
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        String s="",s1="";
        s=input.nextLine(); 
        s1=input.nextLine();
        System.out.println(s);
        System.out.println(s1);        
        int l1,l2;
        l1=s.length();l2=s1.length();
        System.out.println(l1);
        System.out.println(l2);
        if(l1!=l2) System.out.println("NO");
        else 
        {
            int[] a = new int [26];
            int[] a1 = new int [26];
            int[] b = new int[26];
            int[] b1 = new int[26];
            int i;
            for( i=0;i<26;i++)
            {
                if(s.charAt(i)>='a' && s.charAt(i)<='z')
                { 
                    a[s.charAt(i)-'a']++;                    
                }
                else 
                {
                   a1[s.charAt(i)-'A']++;
                }
            }
            for( i=0;i<26;i++)
            {
                if(s1.charAt(i)>='a' && s1.charAt(i)<='z')
                { 
                    b[s1.charAt(i)-'a']++;                    
                }
                else 
                {
                   b1[s1.charAt(i)-'A']++;
                }
            }
            int x=1;
            for( i=0;i<26;i++)
            {
                if(a[i]!=b[i] || a1[i]!=b1[i]) 
                { x=0;break; }
            }
            if(x==1) System.out.println("YES");
            else System.out.println("NO");
        }       
    }
}