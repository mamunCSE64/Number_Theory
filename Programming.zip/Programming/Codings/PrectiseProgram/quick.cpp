#include <bits/stdc++.h>
using namespace std;
void srt(int a[], int l, int h, int n)
{
	if (l >= h)
		return;
	int odd[n], even[n];
	int ii = 0, jj = 0;
	for (int i = l; i < h; i++)
		if (a[i] > a[i + 1])
			swap(a[i], a[i + 1]);
	for (int i = l; i <= h; i++)
	{
		if (a[i] % 2 == 0)
			even[jj++] = a[i];
		else
			odd[ii++] = a[i];
	}
	int k=0,p=0;
	for (int i = l; i <= h; i++)
	{
		if (k<ii)
			 a[i] = odd[k++];
		else
			 a[i] = even[p++];
	}
	int mid = (l + h) / 2;
	srt(a,l,mid,n);
	srt(a,mid+1,h,n);

}
int main()
{
	int n;
	cin >> n;
	int a[n];
	for (int i = 0; i < n; i++)
		cin >> a[i];
	srt(a, 0, n - 1, n);
	for (int i = 0; i < n; i++)
		cout << a[i] << " ";
}