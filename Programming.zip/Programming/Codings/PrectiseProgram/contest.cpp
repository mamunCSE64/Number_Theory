#include <bits/stdc++.h>
#include <iostream>
#define ll long long int
#define pb push_back
#define pob pop_back
#define Pf push_front
#define gcd __gcd
#define int_string to_string
#define string_int stoi
#define mn(v) *min_element(v.begin(), v.end())
#define mx(v) *max_element(v.begin(), v.end())
#define index_character s.find('character')
#define countxchar count(s.begin(), s.end(), 'x')
#define index_ofX_vector find(v.begin(), v.end(), x) - v.begin()
#define yes cout << "YES" << endl
#define no cout << "NO" << endl
#define ne1 cout << "-1" << endl
#define sorted is_sorted(v.begin(), v.end())
#define nl << endl
#define sp << " "
#define mp make_pair
#define fi first
#define se second
#define Mx INT_MAX
#define Mn INT_MIN
#define mod 1000000007
#define pi acos(-1)
// BesidesDuplicateCharacterEraseInString s.erase(unique(s.begin(), s.end()), s.end());
// Upper/lower-> transform(s.begin(), s.end(), s.begin(), ::toupper/tolower)
using namespace std;
ll i, j, k;
ll a[26];
// Don't get stuck on a single approach for long, think of multiple ways
// **********************|| Main Code ||********************************

int main()
{
    ll t = 1;
    // cin >> t;
    while (t--)
    {        
        ll c1,c2,c3,c4,n,m;
        cin>>c1>>c2>>c3>>c4>>n>>m;
        ll a[n],b[m];
        for(i=0;i<n;i++) cin>>a[i];
        for(i=0;i<m;i++) cin>>b[i];
        ll a1,a2,a3,a4;
        a4=c4;
        cout << max({a1,a2,a3,a4}) nl;
    }
}
