#include <bits/stdc++.h>
#include <iostream>
#define ll long long int
#define pb push_back
#define pob pop_back
#define Pf push_front
#define gcd __gcd
#define int_string to_string
#define string_int stoi
#define mn(v) *min_element(v.begin(), v.end())
#define mx(v) *max_element(v.begin(), v.end())
#define index_character s.find('character')
#define countxchar count(s.begin(), s.end(), 'x')
#define index_ofX_vector find(v.begin(), v.end(), x) - v.begin()
#define yes cout << "YES" << endl
#define no cout << "NO" << endl
#define ne1 cout << "-1" << endl
#define sorted is_sorted(v.begin(), v.end())
#define nl << endl
#define sp << " "
#define mp make_pair
#define fi first        
#define se second
#define Mx INT_MAX
#define Mn INT_MIN
#define mod 1000000007
// BesidesDuplicateCharacterEraseInString s.erase(unique(s.begin(), s.end()), s.end());
// Upper/lower-> transform(s.begin(), s.end(), s.begin(), ::toupper/tolower)
using namespace std;
ll i, j, k;
ll a[26];
// Don't get stuck on a single approach for long, think of multiple ways
// **********************|| Main Code ||********************************
struct node
{
   int data;
   struct node *link;
};
struct node *head = NULL;
struct node *nxt = NULL;
void insert(int x)
{
   struct node *tmp;
   if (head == NULL)
   {
      head = new node();
      head->data = x;
      head->link = NULL;
      nxt = head;
      return;
   }
 
   tmp = new node();
   tmp->data = x;
   tmp->link = NULL;
   nxt->link = tmp;
   nxt = tmp;
}
void begin(int x)
{
   struct node *beg;
   if (head == NULL)
   {
      head = new node();
      head->data = x;
      head->link = NULL;
      nxt = head;
      return;
   }
   beg = new node();
   beg->data = x;
   beg->link = head;
   head = beg;
}
void certainpos(int x, int pos)
{
   if(pos==1)
   {
      begin(x);return;
   }
   nxt = head;   
   for (i = 1; i < pos - 1; i++)
      nxt = nxt->link;
   struct node *hello;
   hello = new node;
   hello->data = x;
   hello->link = nxt->link;
   nxt->link = hello;
}
void delfirst()
{
    if(head == NULL){ cout << "List is already empty!" nl;exit(1); }

    struct node *deletefirst=head;
    head=head->link;   
    free(deletefirst->link);
    deletefirst=NULL;
}
void dellast()
{
    if(head == NULL ) cout << "list is already empty!" nl;
    else if(head->link == NULL) 
    {
        free(head);head == NULL;
    }
    else 
    {
        struct node *deleteLast=head;
        while(deleteLast->link->link!=NULL)
        {
            deleteLast=deleteLast->link;
        }
        free(deleteLast->link);
        deleteLast->link=NULL;
    }
}
void print()
{
   nxt = head;
   if (nxt == NULL)
      cout << "List has no elements" nl;
   while (nxt != NULL)
   {
      cout << nxt->data sp;
      nxt = nxt->link;
   }
   cout nl;
}
int main()
{
   ll n, x;
   cout << "How much you want to insert at the end : ";
   cin >> n;
   while (n--)
   {
      cin >> x;
      insert(x);
   }
   print();
   cout << "How much you want to insert at the beginning  : ";
   cin >> n;
   while (n--)
   {
      cin >> x;
      begin(x);
   }
   print();
   ll pos;
   cout << "which position : " nl;
   cin >> pos;
   cout << "Give the value : " nl;
   cin >> x;
   certainpos(x, pos);
   cout << "This is the whole list : " nl;
   print();  
   cout << "after delfirst" nl;
   delfirst();
   print();
   cout << "after dellast" nl;
   dellast();
   print();  
}
