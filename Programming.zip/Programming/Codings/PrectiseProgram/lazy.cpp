#include <bits/stdc++.h>
#include <iostream>
#define ll long long int
#define pb push_back
#define pob pop_back
#define pf push_front
#define pof pop_front
#define gcd __gcd
#define int_string to_string
#define string_int stoi
#define mn(v) *min_element(v.begin(), v.end())
#define mx(v) *max_element(v.begin(), v.end())
#define index_character s.find('character')
#define countxchar count(s.begin(), s.end(), 'x')
#define index_ofX_vector find(v.begin(), v.end(), x) - v.begin()
#define yes cout << "YES" << endl
#define no cout << "NO" << endl
#define n1 cout << "-1" << endl
#define ok cout << "ok" nl
#define sorted is_sorted(v.begin(), v.end())
#define nl << endl
#define sp << " "
#define mp make_pair
#define fi first
#define se second
#define Mx INT_MAX
#define Mn INT_MIN
#define mod %1000000007
const ll N = 2e5+5;
//   freopen("input.txt","r",stdin);freopen("output.txt","w",stdout);
// BesidesDuplicateCharacterEraseInString s.erase(unique(s.begin(), s.end()), s.end());
// Upper/lower-> transform(s.begin(), s.end(), s.begin(), ::toupper/tolower)
using namespace std;
ll i, j, k, n, m;
ll a[26];
//  Don't get stuck on a single approach for long, think of multiple ways
//  **********************|| Main Code ||********************************

ll ar[N],tree[N*4],lazy[N*4];
void build(ll node,ll b,ll e){
    if(b==e) { tree[node]=ar[b];return; }
    ll mid=(b+e)/2;
    build(2*node,b,mid);
    build(2*node+1,mid+1,e);
    tree[node]=tree[2*node]+tree[2*node+1];
}
ll query(ll node,ll b,ll e,ll l,ll r){
    if(lazy[node]){
        ll x=lazy[node];
        lazy[node]=0;
        tree[node]+=x*(e-b+1);
        if(b!=e) lazy[2*node]+=x,lazy[2*node+1]+=x;
    }
    if(r<b or l>e) return 0;
    if(l<=b and r>=e) return tree[node];
    ll mid=(b+e)/2,x,y;
    x=query(2*node,b,mid,l,r);
    y=query(2*node+1,mid+1,e,l,r);
    return x+y;
}
void update(ll node,ll b,ll e,ll l,ll r,ll value){
    if(lazy[node]){
        ll x=lazy[node];
        lazy[node]=0;
        tree[node]+=x*(e-b+1);
        if(b!=e) lazy[2*node]+=x,lazy[2*node+1]+=x;
    }
    if(r<b or l>e) return;
    if(l<=b and r>=e){
        ll x=(e-b+1)*value;
        tree[node]+=x;
        if(b!=e) lazy[2*node]+=value,lazy[2*node+1]+=value;
        return;
    }
    ll mid=(b+e)/2;
    update(2*node,b,mid,l,r,value);
    update(2*node+1,mid+1,e,l,r,value);
    tree[node]=tree[2*node]+tree[2*node+1];
}
int main()
{    
    ll test = 1;
    // cin >> test;
    again:
    while (test--)
    {   
        ll n,q,x,value,l,r,indx;
        cin>>n>>q;
        for(i=1;i<=n;i++) cin>>ar[i];
        build(1,1,n);
        // cout << "Before update:" nl;
        // for(i=1;i<=9;i++) cout << tree[i] sp;cout nl;
        while(q--){
            cin>>x;
            if(x==1){
                cin>>l>>r>>value;
                update(1,1,n,l,r,value);                
            }
            else{
                cin>>l>>r;
                cout << "Sum : " << query(1,1,n,l,r) nl;
            }
        } 
        // cout << "After update:" nl;
        // for(i=1;i<=9;i++) cout << tree[i] sp;cout nl nl;        
    }   
}
