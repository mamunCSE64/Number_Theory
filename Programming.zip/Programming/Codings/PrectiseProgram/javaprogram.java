import java.util.Scanner;

public class javaprogram{
    public static void main(String[] args) {        
        Scanner v=new Scanner(System.in);        
        int x,y;
        x=v.nextInt();
        y=v.nextInt();
        System.out.println(x);
        System.out.println(y);
    }    
}