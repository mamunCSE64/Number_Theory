#include <bits/stdc++.h>
#include <iostream>
#define ll long long int
#define pb push_back
#define pob pop_back
#define Pf push_front
#define gcd __gcd
#define int_string to_string
#define string_int stoi
#define mn(v) *min_element(v.begin(), v.end())
#define mx(v) *max_element(v.begin(), v.end())
#define index_character s.find('character')
#define countxchar count(s.begin(), s.end(), 'x')
#define index_ofX_vector find(v.begin(), v.end(), x) - v.begin()
#define yes cout << "YES" << endl
#define no cout << "NO" << endl
#define ne1 cout << "-1" << endl
#define sorted is_sorted(v.begin(), v.end())
#define nl << endl
#define sp << " "
#define mp make_pair
#define fi first
#define se second
#define Mx INT_MAX
#define Mn INT_MIN
#define mod 1000000007
// BesidesDuplicateCharacterEraseInString s.erase(unique(s.begin(), s.end()), s.end());
// Upper/lower-> transform(s.begin(), s.end(), s.begin(), ::toupper/tolower)
using namespace std;
ll i, j, k;
ll a[26];
// Don't get stuck on a single approach for long, think of multiple ways
// **********************|| Main Code ||********************************
#define MAX 5
int stack_array[MAX];
int top=-1,data;

void push(int data)
{
    if(top==MAX-1)
    {  cout << "Stack is overflow" nl; return; }
    top++;
    stack_array[top]=data;
}
int pop()
{
    int value;
    if(top==-1) { cout << "Stack is underflow" nl; exit(1); }
    value = stack_array[top],top--;
    return value;
}
int peek()
{
    int value;
    if(top==-1) { cout << "Stack is underflow" nl;exit(1);}
    value = stack_array[top];
    return value;
}
void print()
{
    if(top==-1) { cout << "stack is empty" nl; return; }
    for(i=0;i<=top;i++)  
        cout << stack_array[i] sp;   
    cout nl;
}
int main()
{
    int choice;   
    while(1)
    {
        cout nl;
        cout << "1.push" nl;
        cout << "2.pop" nl;
        cout << "3.top" nl;
        cout << "4.to see all elements" nl;
        cout << "5.exit" nl;
        cin>>choice;
        switch (choice)
        {
        case 1 :
            cout <<"enter the element to be pushed: ";
            cin>>data;push(data);
            break;
        case 2 :
            cout <<"The poped element is : ";
            cout << pop() nl;
            break;
        case 3 :
            cout <<"The top elements is : ";
            cout << peek() nl;
            break;
        case 4 :
            cout <<"All elements are : ";
            print();
            break;
        case 5 : return 0;             
        default: 
        cout <<"wrong choice!try again." nl;
            break;
        }    
    }
}
