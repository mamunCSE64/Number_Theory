#include <bits/stdc++.h>
#include <iostream>
#define ll long long int
#define pb push_back
#define pob pop_back
#define pf push_front
#define pof pop_front
#define gcd __gcd
#define int_string to_string
#define string_int stoi
#define mn(v) *min_element(v.begin(), v.end())
#define mx(v) *max_element(v.begin(), v.end())
#define index_character s.find('character')
#define countxchar count(s.begin(), s.end(), 'x')
#define index_ofX_vector find(v.begin(), v.end(), x) - v.begin()
#define yes cout << "YES" << endl
#define no cout << "NO" << endl
#define n1 cout << "-1" << endl
#define sorted is_sorted(v.begin(), v.end())
#define nl << endl
#define sp << " "
#define mp make_pair
#define fi first
#define se second
#define Mx LLONG_MAX
#define Mn LLONG_MIN
#define mod %1000000007
const ll N = 2e5+5;
// freopen("input.txt","r",stdin);freopen("output.txt","w",stdout);
// BesidesDuplicateCharacterEraseInString s.erase(unique(s.begin(), s.end()), s.end());
// Upper/lower-> transform(s.begin(), s.end(), s.begin(), ::toupper/tolower);
using namespace std;
ll i, j, k, n, m;
const ll e=1e+9;
bool comp(pair<ll,ll> a,pair<ll,ll> b){ if(a.fi==b.fi) return (a.se>b.se);
return (a.fi<b.fi); }
// Don't get stuck on a single approach for long, think of multiple ways
// **********************|| Main Code ||********************************
//

int main()
{ 
    ios::sync_with_stdio(0);
    cin.tie(nullptr);

    ll test = 1;  
    cin >> test;    
    again: 
    while (test--)
    {   
        ll n;
        cin>>n;
        ll a[n],m=0,big=Mn;
        for(i=0;i<n;i++){
            cin>>a[i];
            if(a[i]<0) m++;
            big=max(big,a[i]);
        }
        ll sum1=0,sum2=0;
        for(i=0;i<n;i++){
            if(a[i]>0){
                if(i%2) sum1+=a[i];
                else sum2+=a[i];
            }
        }
        cout << max({big,sum1,sum2}) nl;
    }     
}